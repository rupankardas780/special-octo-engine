
  # Enterprise SaaS Dashboard UI

  This is a code bundle for Enterprise SaaS Dashboard UI. The original project is available at https://www.figma.com/design/Cb8GVNt9hKkVaNHCmUUhhv/Enterprise-SaaS-Dashboard-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  